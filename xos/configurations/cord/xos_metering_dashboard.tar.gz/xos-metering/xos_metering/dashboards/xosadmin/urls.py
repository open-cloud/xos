
from django.conf import settings
from django.conf.urls import include
from django.conf.urls import patterns
from django.conf.urls.static import static  # noqa
from django.conf.urls import url


urlpatterns = patterns(
    '',
    url(r'^xosmonitoring/', include('xos_metering.dashboards.xosadmin.xosmonitoring.urls', namespace='xosmonitoring')),
    url(r'^projects/', include('xos_metering.dashboards.xosadmin.projects.urls', namespace='projects')),
    url(r'^users/', include('xos_metering.dashboards.xosadmin.users.urls', namespace='users')),
)
