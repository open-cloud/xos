# The slug of the dashboard to be added to HORIZON['dashboards']. Required.
DASHBOARD = 'xosadmin'

# A list of applications to be added to INSTALLED_APPS.
ADD_INSTALLED_APPS = [
    'xos_metering.dashboards.xosadmin',
]
